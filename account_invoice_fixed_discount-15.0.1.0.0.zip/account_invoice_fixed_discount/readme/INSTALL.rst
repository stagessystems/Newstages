**Warning**: This module is incompatible with
``account_invoice_triple_discount`` which also belongs to `OCA/account-invoicing
<https://github.com/OCA/account-invoicing>`__.
