* At the moment, the simultaneous use of percent and fixed discounts (at
  line level) is not supported.
