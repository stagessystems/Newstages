## Module <om_hr_payroll_account>

#### 16.02.2022
#### Version 15.0.3.0.0
##### IMP
- enhancements

#### 01.02.2022
#### Version 15.0.2.1.0
##### FIX
- journal account
